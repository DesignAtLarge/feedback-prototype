var comment_history = [

	{"rubric_number": "1.1", "comment": "this is a comment about integrals"},
	{"rubric_number": "1.1", "comment": "another comment!"},
	{"rubric_number": "1.1", "comment": "i am commentating"},
	{"rubric_number": "1.2", "comment": "map comment"}
]